// 创建右键菜单项
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "showStickyNote",
    title: "添加置顶内容",
    contexts: ["page"]
  });
});

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "showStickyNote") {
    // 向当前标签页发送消息，显示添加内容的弹窗
    chrome.tabs.sendMessage(tab.id, {
      action: "showAddNoteDialog"
    });
  }
});

// 监听来自content script的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "saveNote") {
    // 保存笔记数据到localStorage
    chrome.storage.local.get({notes: {}}, (result) => {
      const notes = result.notes;
      const url = sender.tab.url;
      
      // 初始化当前页面的笔记数组
      if (!notes[url]) {
        notes[url] = [];
      }
      
      // 添加新笔记
      notes[url].push({
        id: Date.now().toString(),
        text: message.text,
        image: message.image,
        timestamp: Date.now()
      });
      
      // 确保每个页面最多只有6个置顶内容
      if (notes[url].length > 6) {
        notes[url].shift(); // 删除最早的笔记
      }
      
      // 保存更新后的笔记
      chrome.storage.local.set({notes: notes}, () => {
        sendResponse({success: true});
      });
    });
    
    // 保持消息通道开放直到sendResponse被调用
    return true;
  }
  
  if (message.action === "deleteNote") {
    // 删除指定笔记
    chrome.storage.local.get({notes: {}}, (result) => {
      const notes = result.notes;
      const url = sender.tab.url;
      
      if (notes[url]) {
        notes[url] = notes[url].filter(note => note.id !== message.noteId);
        
        // 保存更新后的笔记
        chrome.storage.local.set({notes: notes}, () => {
          sendResponse({success: true});
        });
      } else {
        sendResponse({success: false});
      }
    });
    
    // 保持消息通道开放直到sendResponse被调用
    return true;
  }
});