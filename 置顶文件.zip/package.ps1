# 打包脚本 - 将浏览器插件文件打包成ZIP压缩包

# 设置变量
$pluginName = "置顶文件"
$version = "1.0"
$outputDir = "d:\Maketop\dist"
$outputFile = "$outputDir\$pluginName-v$version.zip"
$tempDir = "$outputDir\temp"

# 创建输出目录
if (-not (Test-Path -Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir
}

# 清理临时目录和旧的输出文件
if (Test-Path -Path $tempDir) {
    Remove-Item -Path $tempDir -Recurse -Force
}
if (Test-Path -Path $outputFile) {
    Remove-Item -Path $outputFile -Force
}

# 创建临时目录
New-Item -ItemType Directory -Path $tempDir
New-Item -ItemType Directory -Path "$tempDir\images"

# 复制文件
Write-Host "正在复制文件..."
Copy-Item -Path "d:\Maketop\manifest.json" -Destination $tempDir
Copy-Item -Path "d:\Maketop\background.js" -Destination $tempDir
Copy-Item -Path "d:\Maketop\content.js" -Destination $tempDir
Copy-Item -Path "d:\Maketop\styles.css" -Destination $tempDir
Copy-Item -Path "d:\Maketop\popup.html" -Destination $tempDir
Copy-Item -Path "d:\Maketop\README.md" -Destination $tempDir
Copy-Item -Path "d:\Maketop\images\*.svg" -Destination "$tempDir\images"

# 创建ZIP文件
Write-Host "正在创建压缩包..."
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($tempDir, $outputFile)

# 清理临时目录
Remove-Item -Path $tempDir -Recurse -Force

# 显示完成信息
Write-Host "\n打包完成！"
Write-Host "插件压缩包已保存至：$outputFile"
Write-Host "\n使用说明："
Write-Host "1. 下载并解压该压缩包"
Write-Host "2. 在Chrome/Edge浏览器中打开扩展管理页面（chrome://extensions/ 或 edge://extensions/）"
Write-Host "3. 开启开发者模式"
Write-Host "4. 点击加载已解压的扩展程序，选择解压后的文件夹"
Write-Host "5. 插件安装成功后即可使用"

# 暂停以便查看输出
Read-Host "按Enter键退出"