// 当页面加载完成后，显示已保存的置顶内容
window.addEventListener('load', () => {
  loadNotes();
});

// 监听来自background script的消息
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'showAddNoteDialog') {
    showAddNoteDialog();
  }
});

// 加载并显示已保存的置顶内容
function loadNotes() {
  chrome.storage.local.get({notes: {}}, (result) => {
    const notes = result.notes;
    const currentUrl = window.location.href;
    
    // 清除现有笔记
    removeAllNotes();
    
    // 显示当前页面的笔记
    if (notes[currentUrl] && notes[currentUrl].length > 0) {
      notes[currentUrl].forEach((note, index) => {
        createNoteElement(note, index);
      });
    }
  });
}

// 显示添加笔记的对话框
function showAddNoteDialog() {
  // 检查是否已经存在对话框，如果有则移除
  const existingDialog = document.getElementById('stickyNoteDialog');
  if (existingDialog) {
    existingDialog.remove();
  }
  
  // 创建对话框容器
  const dialog = document.createElement('div');
  dialog.id = 'stickyNoteDialog';
  dialog.className = 'sticky-note-dialog';
  
  // 创建对话框内容
  dialog.innerHTML = `
    <div class="sticky-note-dialog-content">
      <h3>添加置顶内容</h3>
      <textarea id="noteText" placeholder="输入文字内容..."></textarea>
      <div class="image-upload">
        <label for="noteImage">选择图片：</label>
        <input type="file" id="noteImage" accept="image/*">
        <img id="previewImage" class="preview" src="" alt="预览图片">
      </div>
      <div class="dialog-buttons">
        <button id="saveNoteBtn">确定</button>
        <button id="cancelNoteBtn">取消</button>
      </div>
    </div>
  `;
  
  // 添加对话框到页面
  document.body.appendChild(dialog);
  
  // 图片预览功能
  const fileInput = dialog.querySelector('#noteImage');
  const previewImage = dialog.querySelector('#previewImage');
  
  fileInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        previewImage.src = event.target.result;
        previewImage.style.display = 'block';
      };
      
      reader.readAsDataURL(e.target.files[0]);
    }
  });
  
  // 保存按钮点击事件
  dialog.querySelector('#saveNoteBtn').addEventListener('click', () => {
    const noteText = dialog.querySelector('#noteText').value;
    const imageSrc = previewImage.src || '';
    
    // 发送保存笔记的请求到background script
    chrome.runtime.sendMessage(
      {action: 'saveNote', text: noteText, image: imageSrc},
      (response) => {
        if (response && response.success) {
          // 保存成功后重新加载笔记
          loadNotes();
        }
        // 关闭对话框
        dialog.remove();
      }
    );
  });
  
  // 取消按钮点击事件
  dialog.querySelector('#cancelNoteBtn').addEventListener('click', () => {
    dialog.remove();
  });
  
  // 点击对话框外部关闭对话框
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) {
      dialog.remove();
    }
  });
}

// 创建笔记元素
function createNoteElement(note, index) {
  const noteContainer = document.createElement('div');
  noteContainer.className = 'sticky-note';
  noteContainer.dataset.id = note.id;
  
  // 设置笔记位置
  noteContainer.style.left = `${index * 210 + 20}px`;
  
  // 创建笔记内容
  let contentHTML = '';
  if (note.image) {
    contentHTML += `<img src="${note.image}" alt="笔记图片" class="note-image">`;
  }
  if (note.text) {
    contentHTML += `<p class="note-text">${escapeHTML(note.text)}</p>`;
  }
  
  // 添加删除按钮
  noteContainer.innerHTML = `
    <div class="note-header">
      <button class="delete-note">×</button>
    </div>
    <div class="note-content">
      ${contentHTML}
    </div>
  `;
  
  // 添加删除事件监听
  noteContainer.querySelector('.delete-note').addEventListener('click', () => {
    deleteNote(note.id);
  });
  
  // 添加笔记到页面
  document.body.appendChild(noteContainer);
}

// 删除笔记
function deleteNote(noteId) {
  chrome.runtime.sendMessage(
    {action: 'deleteNote', noteId: noteId},
    (response) => {
      if (response && response.success) {
        // 删除成功后重新加载笔记
        loadNotes();
      }
    }
  );
}

// 移除所有笔记
function removeAllNotes() {
  const notes = document.querySelectorAll('.sticky-note');
  notes.forEach(note => note.remove());
}

// HTML转义函数
function escapeHTML(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// 监听URL变化，重新加载笔记
let lastUrl = window.location.href;
setInterval(() => {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    lastUrl = currentUrl;
    loadNotes();
  }
}, 500);